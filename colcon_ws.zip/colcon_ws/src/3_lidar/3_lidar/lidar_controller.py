import math

import rclpy
from rclpy.node import Node

from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import TwistStamped


class LidarController(Node):
    def __init__(self):
        super().__init__('lidar_controller')

        self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10
        )

        self.cmd_pub = self.create_publisher(
            TwistStamped,
            '/cmd_vel',
            10
        )

        self.state = 'GO'
        self.state_start_time = 0.0

        self.safe_distance = 0.8
        self.forward_speed = 0.08
        self.turn_speed = 1.0
        self.stop_duration = 0.3
        self.turn_duration = 1.57

    def scan_callback(self, msg):
        cmd = TwistStamped()
        cmd.header.stamp = self.get_clock().now().to_msg()
        cmd.header.frame_id = 'base_link'

        n = len(msg.ranges)

        # TurtleBot3 Gazebo 기본 회피 예제 스타일:
        # 0도 = 정면, 30도 = 좌전방, 330도 = 우전방
        check_indices = [0, 30, 330]

        values = []

        for idx in check_indices:
            idx = idx % n
            r = msg.ranges[idx]

            if math.isfinite(r) and msg.range_min <= r <= msg.range_max:
                values.append(r)
            else:
                values.append(msg.range_max)

        front = min(values)

        self.get_logger().info(
            f'r0={values[0]:.2f}, r30={values[1]:.2f}, '
            f'r330={values[2]:.2f}, front={front:.2f}'
        )

        # 앞쪽 0/30/330 중 하나라도 가까우면 회전
        if front < 0.55:
            self.get_logger().info('FRONT OBSTACLE -> TURN')
            cmd.twist.linear.x = 0.0
            cmd.twist.angular.z = 0.8
        else:
            self.get_logger().info('CLEAR -> GO')
            cmd.twist.linear.x = 0.08
            cmd.twist.angular.z = 0.0

        self.cmd_pub.publish(cmd)



def main(args=None):
    rclpy.init(args=args)

    node = LidarController()
    rclpy.spin(node)

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()