import math
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import TwistStamped
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from tf_transformations import euler_from_quaternion


class SimpleObstacleAvoider(Node):
    def __init__(self):
        super().__init__('simple_obstacle_avoider')

        self.cmd_pub = self.create_publisher(TwistStamped, '/cmd_vel', 10)
        self.scan_sub = self.create_subscription(LaserScan, '/scan', self.scan_callback, 10)
        self.odom_sub = self.create_subscription(Odometry, '/odom', self.odom_callback, 10)

        self.front_threshold = 0.25
        self.linear_speed = 0.2
        self.angular_speed = 0.5

          # 추가: 현재 yaw, 목표 yaw
        self.current_yaw = None
        self.target_yaw = None
        self.turn_dir = 0.0

        # 추가: 회전 목표값
        self.turn_angle = math.pi / 2          # 90도
        self.yaw_tolerance = math.radians(5)   # 5도 오차 허용
        # self.rotation_angle = math.pi /6

    def odom_callback(self, msg: Odometry):
        q = msg.pose.pose.orientation

        roll, pitch, yaw = euler_from_quaternion([
            q.x,
            q.y,
            q.z,
            q.w
        ])

        self.current_yaw = yaw

    def scan_callback(self, scan: LaserScan):
        twist = TwistStamped()
        twist.header.stamp = self.get_clock().now().to_msg()
        twist.header.frame_id = 'base_link'

        # odom이 아직 안 들어왔으면 멈춤
        if self.current_yaw is None:
            twist.twist.linear.x = 0.0
            twist.twist.angular.z = 0.0
            self.cmd_pub.publish(twist)
            return

        # 추가: 이미 회전 중이면 scan 판단하지 말고 yaw만 보고 회전
        if self.target_yaw is not None:
            yaw_error = self.target_yaw - self.current_yaw

            while yaw_error > math.pi:
                yaw_error -= 2.0 * math.pi

            while yaw_error < -math.pi:
                yaw_error += 2.0 * math.pi

            if abs(yaw_error) < self.yaw_tolerance:
                self.target_yaw = None
                self.turn_dir = 0.0

                twist.twist.linear.x = 0.15
                twist.twist.angular.z = 0.0
            else:
                twist.twist.linear.x = 0.0
                twist.twist.angular.z = self.angular_speed if yaw_error > 0 else -self.angular_speed

            self.cmd_pub.publish(twist)
            return

        left_vals = [r for r in scan.ranges[:31] if math.isfinite(r)]
        left_avg = sum(left_vals) / len(left_vals) if left_vals else 0.0

        right_vals = [r for r in scan.ranges[-30:] if math.isfinite(r)]
        right_avg = sum(right_vals) / len(right_vals) if right_vals else 0.0

        front_vals = left_vals + right_vals
        front_min = min(front_vals) if front_vals else float('inf')

        if front_min > self.front_threshold:
            twist.twist.linear.x = 0.15
            twist.twist.angular.z = 0.0
        else:
            twist.twist.linear.x = 0.0

            self.turn_dir = 1.0 if left_avg > right_avg else -1.0
            self.target_yaw = self.current_yaw + self.turn_dir * self.turn_angle

            while self.target_yaw > math.pi:
                self.target_yaw -= 2.0 * math.pi

            while self.target_yaw < -math.pi:
                self.target_yaw += 2.0 * math.pi

            twist.twist.angular.z = self.turn_dir * self.angular_speed

        self.cmd_pub.publish(twist)



    def normalize_angle(self, angle):
        return math.atan2(math.sin(angle), math.cos(angle))
def main(args=None):
    rclpy.init(args=args)
    node = SimpleObstacleAvoider()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()