from setuptools import find_packages, setup

package_name = '2_srvmsg'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='user07',
    maintainer_email='chang5907@gmail.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'LCM_ints_server=2_srvmsg.LCM_ints_server:main',
            'LCM_ints_client=2_srvmsg.LCM_ints_client:main',
            'LCM_ints_server=2_srvmsg.LCM_ints_server:main',
            'LCM_ints_client=2_srvmsg.LCM_ints_client:main',

        ],
    },
)
