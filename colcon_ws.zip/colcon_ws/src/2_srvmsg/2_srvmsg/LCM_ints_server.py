import rclpy
from rclpy.node import Node
from custom_interfaces.srv import LCMTwoInts
import math


class LCMTwoIntsServer(Node):
    def __init__(self):
        super().__init__('srv_server')

        self.srv = self.create_service(LCMTwoInts, '/lcm_two_ints', self.srv_callback)
        self.get_logger().info('Srv Server Ready.')

    def srv_callback(self, request, response):
        response.LCM.num = request.a.num + request.b.num
        
        self.get_logger().info(f'Incoming request\na: {request.a.num}, b: {request.b.num}')
        self.get_logger().info(f'Sending back response: [{response.sum.num}]')
        
        return response


def main():
    rclpy.init()
    node = LCMTwoIntsServer()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
