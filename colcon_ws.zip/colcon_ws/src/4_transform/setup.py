from setuptools import find_packages, setup

package_name = '4_transform'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='user07',
    maintainer_email='chang5907@gmail.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'tf_dynamic=4_transform.tf_dynamic:main',
            'tf_listener=4_transform.tf_listener:main',
            'tf_static=4_transform.tf_static:main',
        ],
    },
)
