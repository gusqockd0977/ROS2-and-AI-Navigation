import rclpy
from rclpy.node import Node
from tf2_geometry_msgs import PointStamped
from sensor_msgs.msg import LaserScan
import tf2_ros
import math

class TFListenerLaser(Node):
    def __init__(self):
        super().__init__('laser_tf')

        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        self.timer = self.create_timer(0.5, self.lookup_tf)

    def scan_callback(self, msg: LaserScan):
        i = 0
        angle = msg.angle_min

        for distance in msg.ranges:
            if distance == float('inf') or math.isnan(distance):
                angle += msg.angle_increment
                continue
                
            x = distance * math.cos(angle)
            y = distance * math.sin(angle)

            point = PointStamped()
            point.header = msg.header
            point.point.x = x
            point.point.y = y
            point.point.z = 0.0

            try:
                transformed = self.tf_buffer.transform(point, 'hello_base_link')
                self.get_logger().info(
                    f"[{i}] TF point: x={transformed.point.x:.2f}, "
                )

    def lookup_tf(self):
        point = PointStamped()
        # point.header.frame_id = 'hello_base_link'
        # point.header.frame_id = 'hello_laser'
        point.header.frame_id = 'hello_base_link'
        point.header.stamp = rclpy.time.Time()
        point.point.x = 0.0
        point.point.y = 0.0
        point.point.z = 0.0

        try:
            # transformed = self.tf_buffer.transform(point, 'hello_laser')
            # transformed = self.tf_buffer.transform(point, 'hello_base_link')
            transformed = self.tf_buffer.transform(point, 'hello_odom')

            self.get_logger().info(
                f"TF point: x={transformed.point.x:.2f}, y={transformed.point.y:.2f}, z={transformed.point.z:.2f}"
            )

        except Exception as e:
            self.get_logger().warn(f"TF not ready: {e}")

def main():
    rclpy.init()
    node = TFListener()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()