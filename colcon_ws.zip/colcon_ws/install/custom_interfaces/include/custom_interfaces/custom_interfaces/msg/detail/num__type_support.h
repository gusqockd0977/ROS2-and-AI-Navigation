// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from custom_interfaces:msg/Num.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "custom_interfaces/msg/num.h"


#ifndef CUSTOM_INTERFACES__MSG__DETAIL__NUM__TYPE_SUPPORT_H_
#define CUSTOM_INTERFACES__MSG__DETAIL__NUM__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "custom_interfaces/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_custom_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  custom_interfaces,
  msg,
  Num
)(void);

#ifdef __cplusplus
}
#endif

#endif  // CUSTOM_INTERFACES__MSG__DETAIL__NUM__TYPE_SUPPORT_H_
